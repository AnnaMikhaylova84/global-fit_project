# Rotating 3D cube hover effect

### [Documentation and demo](http://stanko.github.io/cube-3D-rotate-grid/).

[![](http://i.imgur.com/yxSfuCB.png)](http://stanko.github.io/cube-3D-rotate-grid/)

Licenced under [MIT license](https://github.com/Stanko/cube-3D-rotate-grid/blob/gh-pages/LICENSE.md).


